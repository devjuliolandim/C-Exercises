#include <stdio.h>

int main(){

int i = 0;

while(i<256){
printf("%d\n", i);
i++;

}




}
