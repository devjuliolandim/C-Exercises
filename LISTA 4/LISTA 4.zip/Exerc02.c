#include <stdio.h>

int main(){

int i; 
char c;

for(i= 32; i<=255; i++){
	c=(char)i;
	printf("%d) %c\n", i,c);

}


}
