#include<stdio.h>

int main(){

int num;

	printf("Os nums. multiplos de 3:\n");
	for(num=1; num<= 100; num++){
	if(num%3==0){
	printf("%d\n",num);
	}
	}

}
