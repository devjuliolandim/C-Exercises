#include <stdio.h>

int main(){

int N, termos = 1, cont;

printf("Digite um num.\n");
scanf("%d", &N);

for(cont=1; cont<= N; cont++){
printf("%d\n", termos);
termos += 4;


}





}
